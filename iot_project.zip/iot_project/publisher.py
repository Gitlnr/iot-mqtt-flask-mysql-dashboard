import paho.mqtt.client as mqtt
import time
import random

client = mqtt.Client()
client.connect("localhost", 1883, 60)

while True:
    temp = random.randint(20, 35)
    client.publish("sensor/temperature", temp)
    print("Sent:", temp)
    time.sleep(5)