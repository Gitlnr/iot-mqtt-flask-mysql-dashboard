import paho.mqtt.client as mqtt
import mysql.connector

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="your_password",
    database="iot_db"
)
#replace password with yourpassword

cursor = db.cursor()

device_status = "OFF"  # global variable

def on_connect(client, userdata, flags, rc):
    client.subscribe("sensor/temperature")
    client.subscribe("device/control")   

def on_message(client, userdata, msg):
    global device_status

    if msg.topic == "device/control":
        device_status = msg.payload.decode()
        print("Status changed:", device_status)

    elif msg.topic == "sensor/temperature":
        temp = msg.payload.decode()
        print("Temp:", temp)

        sql = "INSERT INTO temperature (value, device_status) VALUES (%s, %s)"
        cursor.execute(sql, (temp, device_status))
        db.commit()

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect("localhost", 1883, 60)
client.loop_forever()