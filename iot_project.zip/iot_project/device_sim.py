import paho.mqtt.client as mqtt

def on_message(client, userdata, msg):
    command = msg.payload.decode()
    print("Device received:", command)

    if command == "ON":
        print("Yard Dog Turn ON")
    elif command == "OFF":
        print("Yard Dog Turn OFF")

client = mqtt.Client()
client.connect("localhost", 1883, 60)
client.subscribe("device/control")

client.on_message = on_message
client.loop_forever()