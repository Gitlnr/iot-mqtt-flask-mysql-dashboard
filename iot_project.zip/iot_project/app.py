from flask import Flask, render_template
import mysql.connector
import paho.mqtt.publish as publish

app = Flask(__name__)

@app.route("/")
def index():
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="your_password", 
        database="iot_db"
#replace password with yourpassword
    )
    cursor = db.cursor()
    cursor.execute("SELECT * FROM temperature ORDER BY id DESC LIMIT 20")
    data = cursor.fetchall()

    temps = [row[1] for row in data]
    times = [str(row[2]) for row in data]

    return render_template("index.html", temps=temps, times= times)

@app.route("/on")
def turn_on():
    print("ON button clicked")
    publish.single("device/control", "ON", hostname="localhost")
    return "ON sent"

@app.route("/off")
def turn_off():
    print("OFF button clicked")
    publish.single("device/control", "OFF", hostname="localhost")
    return "OFF sent"

app.run(debug=True)

# comment line